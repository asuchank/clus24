#!/bin/bash
PF_RULES="/tmp/pf.rules"
echo "block drop quick from 23.0.0.0/8 to any" > $PF_RULES
sudo pfctl -f $PF_RULES
echo "Blocked IP range 23.0.0.0/8"
sleep 15
sudo pfctl -f /etc/pf.conf
echo "Unblocked IP range 23.0.0.0/8"
rm $PF_RULES

